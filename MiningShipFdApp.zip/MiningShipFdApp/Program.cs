﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
//Racon
using Racon;
using Racon.RtiLayer;
// Application
using AMVS.Som;

namespace AMVS
{
  class Program
  {
    // Globals
    public static CSimulationManager manager = new CSimulationManager();
    // Local object
    //static CShip ship = new CMiningShip(); // Own ship
    static bool Terminate = false; // exit switch for app
    static bool test = false; // guard for testing for various RTI interface

    // Local data structures 
    static public BindingList<AMVS.Som.CMiningShipHlaObject> Miningship; //
    static public BindingList<AMVS.Som.CNavShipHlaObject> NavigationShip; //     
    static public BindingList<AMVS.Som.CAsteroidHlaObject> Asteroids;
 

   
    static void Main(string[] args)
    {
      // *************************************************
      // Initialization
      // *************************************************
      // Program initialization


      Miningship = new BindingList<CMiningShipHlaObject>(); //
      NavigationShip = new BindingList<CNavShipHlaObject>(); //     
      Asteroids = new BindingList<CAsteroidHlaObject>();

      // UI initialization
      PrintVersion();

      Thread ConsoleKeyListener = new Thread(new ThreadStart(ProcessKeyboard));
      ConsoleKeyListener.Name = "KeyListener";

      // Racon Initialization
      // Getting the information/debugging messages from RACoN
      Console.WriteLine("---");
      manager.federate.StatusMessageChanged += Federate_StatusMessageChanged;
      manager.federate.LogLevel = LogLevel.ALL;
      Console.WriteLine("---");

      // initialization of Ship Properties
      Console.ForegroundColor = ConsoleColor.Gray;
      setMiningShipConfiguration(); // get user input
      
      ConsoleKeyListener.Start();// start keyboard event listener

      // *************************************************
      // Initialization
      // *************************************************
      // Federation Initialization
      // connect, create and join to federation execution, declare object model
      bool result = manager.federate.InitializeFederation(manager.federate.FederationExecution);

	/// Connect
            manager.federate.Connect(Racon.CallbackModel.EVOKED, manager.federate.FederationExecution.ConnectionSettings);
            // Create federation execution
            manager.federate.CreateFederationExecution(manager.federate.FederationExecution.Name, manager.federate.FederationExecution.FomModules);
            // Join federation execution
            manager.federate.JoinFederationExecution( manager.federate.FederationExecution.FederateName, manager.federate.FederationExecution.FederateType, manager.federate.FederationExecution.Name, manager.federate.FederationExecution.FomModules);

            // Declare Capability
            manager.federate.DeclareCapability();

	// *************************************************
        // Main Simulation Loop - loops until ESC is pressed
        // *************************************************
          Console.WriteLine("-- \nMiningShip has joined Federation!\n--");
	do
            {
                if (manager.federate.FederateState.HasFlag(Racon.FederateStates.JOINED))
                    manager.federate.Run();
                // Console.WriteLine("--\n --> federate is checking callbacks.. \n--");                      

                // listen for keyboard events on infinite loop

            } while (!Terminate); // loop ends here

      // *************************************************
      // Shutdown
      // *************************************************
      // Finalize user interface
      ConsoleKeyListener.Abort();
      // Finalize Federation Execution
      // Remove objects
      
      bool v;
      manager.federate.DeleteObjectInstance(Miningship[0]);
      manager.federate.DeleteObjectInstance(NavigationShip[0]);
      foreach(var asteroid in Asteroids)
	 v = manager.federate.DeleteObjectInstance(asteroid);


      // Leave and destroy federation execution
      bool result2 = manager.federate.FinalizeFederation(manager.federate.FederationExecution);
      //bool result2 = manager.federate.FinalizeFederation(manager.federate.FederationExecution, Racon.ResignAction.DELETE_OBJECTS);

      // Dumb trace log
      StreamWriter file = new System.IO.StreamWriter(@".\TraceLog.txt");
      file.WriteLine(manager.federate.TraceLog);
      file.Close();
      //Console.WriteLine(manager.federate.TraceLog.ToString());

      // Keep the console window open in debug mode.
      Console.WriteLine("Press any key to exit.");
      Console.ReadKey();
    }

      // Racon Information received
      private static void Federate_StatusMessageChanged(object sender, EventArgs e)
      {
            Console.ResetColor();
            Console.WriteLine((sender as CMiningShipFdApp).StatusMessage);
      }

     // Process KB events
        private static void ProcessKeyboard()
        {
            do
            {
                // input processing
                switch (Console.ReadKey(true).Key)
                {
                    // Print status of uavfdapp
                    case ConsoleKey.P:
                        Console.ForegroundColor = ConsoleColor.Yellow;
                        printStatus();
                        break;
                    // get uavrn count in the federate
                    case ConsoleKey.M:
                        Console.ForegroundColor = ConsoleColor.Blue;
			bool res = manager.federate.SendMessage(false);
                        Console.WriteLine($" --> begin mining \n---");
                        break;

                   case ConsoleKey.F:
                        Console.ForegroundColor = ConsoleColor.Blue;
			bool res1 = manager.federate.SendMessage(true);
                        Console.WriteLine($" --> Finished mining, capacity has decrease \n---");
                        break;

		   case ConsoleKey.D:
                        Console.ForegroundColor = ConsoleColor.Blue;
                        Console.WriteLine($" --> reached MAX capacity, returning to home base\n---");
			Terminate = true;
                        break;

                    case ConsoleKey.Escape:
                        Terminate = true;
                        break;
                    default:
                        break;
                }
            } while (true);
        }

	public static void setMiningShipConfiguration()
	{
            CMiningShipHlaObject newMiningShip = new CMiningShipHlaObject(manager.federate.Som.MiningShipOC);
	    newMiningShip.capacity = 10;
	    newMiningShip.status = "Operational and waiting to connect to Navigation Ship ";
	    newMiningShip.heading = "East";
	    newMiningShip.position = "(0,0)";
            //Encapsulate
            Miningship.Add(newMiningShip);
            Console.WriteLine($"--------\n The Mining Ship is online and functional");
        }

        private static void printStatus() // need this to print UAVFdApp status. could loop calling printUAVConfiguration? 
        {
            // Console.ForegroundColor = ConsoleColor.Blue;
            Console.WriteLine("------------------ MiningShip Status ---------------");
            Console.WriteLine($"---\n Mining Ship capacity {Miningship[0].capacity}");
	    Console.WriteLine($"---\n Mining Ship Status {Miningship[0].status}");
	    Console.WriteLine($"---\n Mining Ship Heading {Miningship[0].heading}");

            Console.WriteLine("--> Mining Ship is operational \n---");
           

            Console.WriteLine("--------------------------------------------------");
        }


	// Print version
        private static void PrintVersion()
        {
            Console.WriteLine(
              "-----------------------------------------------------------------------------\n"
              + "                        " + "MiningShip v1.0.0" + "\n"
              + "-----------------------------------------------------------------------------");
        }


  }
}