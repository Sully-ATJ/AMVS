// **************************************************************************************************
//		CMiningShipMessageIC
//
//		generated
//			by		: 	Simulation Generator (SimGe) v.0.3.3
//			at		: 	Wednesday, January 26, 2022 12:35:06 AM
//		compatible with		: 	RACoN v.0.0.2.5
//
//		copyright		: 	(C) 
//		email			: 	
// **************************************************************************************************
/// <summary>
/// This class is extended from the object model of RACoN API
/// </summary>

// System
using System;
using System.Collections.Generic; // for List
// Racon
using Racon;
using Racon.RtiLayer;
// Application
using AMVS.Som;


namespace AMVS.Som
{
  public class CMiningShipMessageIC : HlaInteractionClass
  {
    #region Declarations
    public HlaParameter MiningStatus;
    #endregion //Declarations
    
    #region Constructor
    public CMiningShipMessageIC() : base()
    {
      // Initialize Class Properties
      Name = "HLAinteractionRoot.MiningShipMessage";
      ClassPS = PSKind.Subscribe;
      
      // Create Parameters
      // MiningStatus
      MiningStatus = new HlaParameter("MiningStatus");
      Parameters.Add(MiningStatus);

      //CapacityStatus = new HlaParameter("CapacityStatus");
      //Parameters.Add(CapacityStatus);
    }
    #endregion //Constructor
  }
}
