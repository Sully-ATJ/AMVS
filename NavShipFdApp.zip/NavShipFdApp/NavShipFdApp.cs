// **************************************************************************************************
//		CNavShipFdApp
//
//		generated
//			by		: 	Simulation Generator (SimGe) v.0.3.3
//			at		: 	Wednesday, January 26, 2022 12:35:06 AM
//		compatible with		: 	RACoN v.0.0.2.5
//
//		copyright		: 	(C) 
//		email			: 	
// **************************************************************************************************
/// <summary>
/// The application specific federate that is extended from the Generic Federate Class of RACoN API. This file is intended for manual code operations.
/// </summary>

// System
using System;
using System.Collections.Generic; // for List
// Racon
using Racon;
using Racon.RtiLayer;
// Application
using AMVS.Som;

namespace AMVS
{
  public partial class CNavShipFdApp : Racon.CGenericFederate
  {
    #region Manually Added Code
    
    // Local Data
    private CSimulationManager manager;
    
    #region Constructor
    public CNavShipFdApp(CSimulationManager parent) : this()
    {
      manager = parent; // Set simulation manager
      // Create regions manually
    }
    #endregion //Constructor
    #region Event Handlers
    #region Federate Callback Event Handlers
    #region Federation Management Callbacks

    // FdAmb_OnSynchronizationPointRegistrationConfirmedHandler
    public override void FdAmb_OnSynchronizationPointRegistrationConfirmedHandler(object sender, HlaFederationManagementEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_OnSynchronizationPointRegistrationConfirmedHandler(sender, data);
      
      #region User Code
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($"\n>>>> NavShipFdApp request for ({data.Label}) is accepted by RTI." + Environment.NewLine);
            #endregion //User Code
    }


    // FdAmb_OnSynchronizationPointRegistrationFailedHandler
    public override void FdAmb_OnSynchronizationPointRegistrationFailedHandler(object sender, HlaFederationManagementEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_OnSynchronizationPointRegistrationFailedHandler(sender, data);
      
      #region User Code
      Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine($"\n>>>> NavShipFdApp request for ({data.Label}) is NOT accepted by RTI. Reason: {data.Reason}" + Environment.NewLine);
            #endregion //User Code
    }

    // FdAmb_SynchronizationPointAnnounced
    public override void FdAmb_SynchronizationPointAnnounced(object sender, HlaFederationManagementEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_SynchronizationPointAnnounced(sender, data);
      
      #region User Code
      //Report.WriteLine($"Ready for zone transfer. Label: {data.Label}" + Environment.NewLine);
      SynchronizationPointAchieved(data.Label, true);
      #endregion //User Code
    }

    // FdAmb_FederationSynchronized
    public override void FdAmb_FederationSynchronized(object sender, HlaFederationManagementEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_FederationSynchronized(sender, data);
      
      #region User Code
      Console.ForegroundColor = ConsoleColor.Green;
      Console.WriteLine($"simulation pacing ({data.Label}) is completed." + Environment.NewLine);
      #endregion //User Code
    }

    // FdAmb_FederationSaved
    public override void FdAmb_FederationSaved(object sender, HlaFederationManagementEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_FederationSaved(sender, data);
      
      if (data.Success)
            {
                Console.WriteLine("The Federation has been saved");
            }
      else
            {
                // federation not saved. The save failure reason is
                string information = data.Reason;
                Console.WriteLine("The save failure reason: " + information);
            }
      }

    // FdAmb_ConfirmFederationRestorationRequestHandler
    public override void FdAmb_ConfirmFederationRestorationRequestHandler(object sender, HlaFederationManagementEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_ConfirmFederationRestorationRequestHandler(sender, data);
      
      if (data.Success)
      {
        // restoration request is confirmed
      }
      else
      {
        // restoration request is failed. This callback does not provide a reason.
      }
    }

    #endregion //Federation Management Callbacks


    #region Declaration Management Callbacks

// FdAmb_StartRegistrationForObjectClassAdvisedHandler
    public override void FdAmb_StartRegistrationForObjectClassAdvisedHandler(object sender, HlaDeclarationManagementEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_StartRegistrationForObjectClassAdvisedHandler(sender, data);
      
      #region User Code
      // Check that this is for the NavShipOC
      if (data.ObjectClassHandle == Som.NavShipOC.Handle)
        RegisterHlaObject(Program.NavigationShip[0]);
      #endregion //User Code
    }
    // FdAmb_StopRegistrationForObjectClassAdvisedHandler
    public override void FdAmb_StopRegistrationForObjectClassAdvisedHandler(object sender, HlaDeclarationManagementEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_StopRegistrationForObjectClassAdvisedHandler(sender, data);
      
      #region User Code
      #endregion //User Code
    }
    // FdAmb_TurnInteractionsOffAdvisedHandler
    public override void FdAmb_TurnInteractionsOffAdvisedHandler(object sender, HlaDeclarationManagementEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_TurnInteractionsOffAdvisedHandler(sender, data);
      
      #region User Code
      // Interactions aren't ever turned off.
      #endregion //User Code
    }
    // FdAmb_TurnInteractionsOnAdvisedHandler
    public override void FdAmb_TurnInteractionsOnAdvisedHandler(object sender, HlaDeclarationManagementEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_TurnInteractionsOnAdvisedHandler(sender, data);
      
      #region User Code
      //interactions are always on
      #endregion //User Code
    }

    #endregion //Declaration Management Callbacks

    #region Object Management Callbacks

    // FdAmb_ObjectDiscoveredHandler
    public override void FdAmb_ObjectDiscoveredHandler(object sender, HlaObjectEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_ObjectDiscoveredHandler(sender, data);
      
            #region User Code
            // Check the class type of the discovered object - Navship, MiningShip or Asteroid
            if (data.ClassHandle == Som.NavShipOC.Handle) // Navigation Ship
            {
                // Create and add a new naigation ship to the list
                CNavShipHlaObject newNS = new CNavShipHlaObject(data.ObjectInstance);
                newNS.Type = Som.NavShipOC;
                Program.NavigationShip.Add(newNS);
		Console.WriteLine($"--------New navship discovered!!-------");
                // Request Update Values of Attributes        
                RequestAttributeValueUpdate(newNS, null);
            }
            else if (data.ClassHandle == Som.MiningShipOC.Handle) // A Mining Ship
            {
                // Create and add a new mining ship to the list
                CMiningShipHlaObject newMS = new CMiningShipHlaObject(data.ObjectInstance);
                newMS.Type = Som.MiningShipOC;
                Program.Miningship.Add(newMS);
		Console.WriteLine($"--------New MiningShip discovered!!-------");
		Program.NavigationShip[0].status = "Linked with mining ship, now explore the asteroid belt.";
		Program.NavigationShip[0].position = "(10,1)";

                // Request Update Values of Attributes        
                // (1) Request update values of all attributes for a specific object instance
                RequestAttributeValueUpdate(newMS, null);
            }
            else if (data.ClassHandle == Som.AsteroidOC.Handle) // An Asteroid
            {
                // Create and add a new asteroid to the list
                CAsteroidHlaObject newAsteroid = new CAsteroidHlaObject(data.ObjectInstance);
                newAsteroid.Type = Som.AsteroidOC;
                Program.Asteroids.Add(newAsteroid);
		Console.WriteLine($"--------New Asteriod discovered!!-------");

                // Request Update Values of Attributes        
                // (1) Request update values of all attributes for a specific object instance
                RequestAttributeValueUpdate(newAsteroid, null);
            }
            #endregion //User Code
    }
    // FdAmb_ObjectRemovedHandler
    public override void FdAmb_ObjectRemovedHandler(object sender, HlaObjectEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_ObjectRemovedHandler(sender, data);
      
            #region User Code
            Console.WriteLine("in object removed handler.");
            #endregion //User Code
    }

    // FdAmb_AttributeValueUpdateRequestedHandler
    public override void FdAmb_AttributeValueUpdateRequestedHandler(object sender, HlaObjectEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_AttributeValueUpdateRequestedHandler(sender, data);
      
     #region User Code
      // !!! If this federate is created only one object instance, then it is sufficient to check the handle of that object, otherwise we need to check all the collection
      if (data.ObjectInstance.Handle == Program.NavigationShip[0].Handle)
      {
        // We can update all attributes if we dont want to check every attribute.
        var timestamp = Time + Lookahead;
        UpdateNavShipAttributes(Program.NavigationShip[0], timestamp);
      }
      #endregion //User Code
    }
    // FdAmb_ObjectAttributesReflectedHandler
    public override void FdAmb_ObjectAttributesReflectedHandler(object sender, HlaObjectEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_ObjectAttributesReflectedHandler(sender, data);
      
      #region User Code
      #endregion //User Code
    }
    // FdAmb_InteractionReceivedHandler
    public override void FdAmb_InteractionReceivedHandler(object sender, HlaInteractionEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_InteractionReceivedHandler(sender, data);
      
      #region User Code
      //check interaction type
      if(data.Interaction.ClassHandle == Som.MiningShipMessageIC.Handle)
      {
        bool miningstatus = true;
        string capacitystatus = "";
        var ts = new DateTime();


        foreach (var item in data.Interaction.Parameters)
        {
          if (Som.MiningShipMessageIC.MiningStatus.Handle == item.Handle) miningstatus = item.GetValue<bool>();
         // else if (Som.MiningShipMessageIC.CapacityStatus.Handle == item.Handle) capacitystatus = item.GetValue<string>();

        }
	if(miningstatus){
		Console.WriteLine("----\n<<<< Interaction received\n sender: MiningShip" +  "\n MiningStatus: " + "Still Mining\n---");
	}
	else{
                Console.WriteLine("----\n<<<< Interaction received\n sender: MiningShip" +  "\n MiningStatus: " + "Done Mining Asteroid\n---");
	}
      }
      else if(data.Interaction.ClassHandle == Som.AsteroidMessageIC.Handle)
      {
        string asteroidType = "";
        string position = "";
        var ts = new DateTime();


        foreach (var item in data.Interaction.Parameters)
        {
          if (Som.AsteroidMessageIC.AsteroidType.Handle == item.Handle) asteroidType = item.GetValue<string>();
          //else if (Som.AsteroidMessageIC.Position.Handle == item.Handle) position = item.GetValue<string>();

        }

                Console.WriteLine("----\n<<<< Interaction received\n sender: Asteroid "  + "\n Asteroid Type: " + asteroidType + "\n Position " + position + "\n---");
      }

 
      #endregion //User Code
    }

        #endregion //Object Management Callbacks
        //#region Ownership Management Callbacks
        // FdAmb_AttributeOwnershipAssumptionRequested
        // public override void FdAmb_AttributeOwnershipAssumptionRequested(object sender, HlaOwnershipManagementEventArgs data)
        //{
        // Call the base class handler
        //base.FdAmb_AttributeOwnershipAssumptionRequested(sender, data);

        //#region User Code

        #endregion //User Code
        // }
        #endregion
        #endregion //Manually Added Code
        private void UpdateNavShipAttributes(CNavShipHlaObject navship, double timestamp )
        {
            navship.AddAttributeValue(Som.NavShipOC.Nposition, navship.position);
            navship.AddAttributeValue(Som.NavShipOC.Nheading, navship.heading);
            navship.AddAttributeValue(Som.NavShipOC.NStatus, navship.status);
            UpdateAttributeValues(navship, timestamp);
        }

	public bool SendMessage(string txt)
	{
		
		
		HlaInteraction interaction = new Racon.RtiLayer.HlaInteraction(Som.NavShipMessageIC, "NavShipMessage");
		interaction.AddParameterValue(Som.NavShipMessageIC.NewDirection, txt); // String

		try
      		{
        	SendInteraction(interaction);
        	//MessageRetraction handle = SendInteraction(interaction);
        	//Retract(handle);
       		return true;
      		}
      		catch (Exception)
      		{
        		return false;
      		}
		
	}
   }
}
