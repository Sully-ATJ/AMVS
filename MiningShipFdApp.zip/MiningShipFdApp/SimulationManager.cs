// **************************************************************************************************
//		CSimulationManager
//
//		generated
//			by		: 	Simulation Generator (SimGe) v.0.3.3
//			at		: 	Wednesday, January 26, 2022 12:35:07 AM
//		compatible with		: 	RACoN v.0.0.2.5
//
//		copyright		: 	(C) 
//		email			: 	
// **************************************************************************************************
/// <summary>
/// The Simulation Manager manages the (multiple) federation execution(s) and the (multiple instances of) joined federate(s).
/// </summary>

// System
using System;
using System.Collections.Generic; // for List
// Racon
using Racon;
using Racon.RtiLayer;
// Application
using AMVS.Som;

namespace AMVS
{
  public class CSimulationManager
  {
    #region Declarations
    // Communication layer related structures
    public CMiningShipFdApp federate; //Application-specific federate 
    // Local data structures
    // TODO: user-defined data structures are declared here
    #endregion //Declarations
    
    #region Constructor
    public CSimulationManager()
    {
      // Initialize the application-specific federate
      federate = new CMiningShipFdApp(this);
      // Initialize the federation execution
      federate.FederationExecution.Name = "Asteroid_Belt";
      federate.FederationExecution.FederateType = "VehicleType";
      federate.FederationExecution.ConnectionSettings = "rti://127.0.0.1";
      // Handle RTI type variation
      initialize();
    }
    #endregion //Constructor
    
    #region Methods
    // Handles naming variation according to HLA specification
    private void initialize()
    {
      switch (federate.RTILibrary)
      {
        case RTILibraryType.HLA13_DMSO: case RTILibraryType.HLA13_Portico: case RTILibraryType.HLA13_OpenRti:
                federate.Som.NavShipOC.Name = "objectRoot.NavShip";
                federate.Som.NavShipOC.PrivilegeToDelete.Name = "privilegeToDelete";
                federate.Som.MiningShipOC.Name = "objectRoot.MiningShip";
                federate.Som.MiningShipOC.PrivilegeToDelete.Name = "privilegeToDelete";
                federate.Som.AsteroidOC.Name = "objectRoot.Asteroid";
                federate.Som.AsteroidOC.PrivilegeToDelete.Name = "privilegeToDelete";
                federate.Som.MiningShipMessageIC.Name = "interactionRoot.MiningShipMessage";
                federate.Som.NavShipMessageIC.Name = "interactionRoot.NavShipMessage";
                federate.FederationExecution.FDD = @"C:\Users\sulei\Desktop\AMVS\amvs\MiningShipFdApp\FDDs\AmvsFom.fed";
        break;
        case RTILibraryType.HLA1516e_Portico: case RTILibraryType.HLA1516e_OpenRti:
                federate.Som.NavShipOC.Name = "HLAobjectRoot.NavShip";
                federate.Som.NavShipOC.PrivilegeToDelete.Name = "HLAprivilegeToDeleteObject";
                federate.Som.MiningShipOC.Name = "HLAobjectRoot.MiningShip";
                federate.Som.MiningShipOC.PrivilegeToDelete.Name = "HLAprivilegeToDeleteObject";
                federate.Som.AsteroidOC.Name = "HLAobjectRoot.Asteroid";
                federate.Som.AsteroidOC.PrivilegeToDelete.Name = "HLAprivilegeToDeleteObject";
                federate.Som.MiningShipMessageIC.Name = "HLAinteractionRoot.MiningShipMessage";
                federate.Som.NavShipMessageIC.Name = "HLAinteractionRoot.NavShipMessage";
                federate.FederationExecution.FDD = @"C:\Users\sulei\Desktop\AMVS\amvs\MiningShipFdApp\FDDs\AmvsFom.xml";
        break;
      }
    }
    #endregion //Methods
  }
}
