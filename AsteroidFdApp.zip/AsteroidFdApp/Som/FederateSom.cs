// **************************************************************************************************
//		FederateSom
//
//		generated
//			by		: 	Simulation Generator (SimGe) v.0.3.3
//			at		: 	Wednesday, January 26, 2022 12:35:07 AM
//		compatible with		: 	RACoN v.0.0.2.5
//
//		copyright		: 	(C) 
//		email			: 	
// **************************************************************************************************
/// <summary>
/// This class is extended from the object model of RACoN API
/// </summary>

// System
using System;
using System.Collections.Generic; // for List
// Racon
using Racon;
using Racon.RtiLayer;
// Application
using AMVS.Som;


namespace AMVS.Som
{
  public class FederateSom : Racon.ObjectModel.CObjectModel
  {
    #region Declarations
    #region SOM Declaration
    public AMVS.Som.CNavShipOC NavShipOC;
    public AMVS.Som.CMiningShipOC MiningShipOC;
    public AMVS.Som.CAsteroidOC AsteroidOC;
    public AMVS.Som.CAsteroidMessageIC AsteroidMessageIC;
    #endregion
    #endregion //Declarations
    
    #region Constructor
    public FederateSom() : base()
    {
      // Construct SOM
      NavShipOC = new AMVS.Som.CNavShipOC();
      AddToObjectModel(NavShipOC);
      MiningShipOC = new AMVS.Som.CMiningShipOC();
      AddToObjectModel(MiningShipOC);
      AsteroidOC = new AMVS.Som.CAsteroidOC();
      AddToObjectModel(AsteroidOC);
      AsteroidMessageIC = new AMVS.Som.CAsteroidMessageIC();
      AddToObjectModel(AsteroidMessageIC);
    }
    #endregion //Constructor
  }
}
