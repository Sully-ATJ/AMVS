﻿// System
using System;
using System.Collections.Generic; // for List
using System.ComponentModel;
using System.Threading;
// Racon
using Racon;
using Racon.RtiLayer;
// Application
using AMVS.Som;

namespace AMVS
{
    class Program
    {
        //Simulation manager
        public static AMVS.CSimulationManager manager = new CSimulationManager();

	//Communication layer relate structures
        static public CNavShipFdApp federate;
        //Local Data structures
        static public BindingList<AMVS.Som.CNavShipHlaObject> NavigationShip;
        static public BindingList<AMVS.Som.CMiningShipHlaObject> Miningship;
        static public BindingList<AMVS.Som.CAsteroidHlaObject> Asteroids;
	
	static public bool Terminate = false; // user defined quit

        //Main Program
        static void Main(string[] args)
        {
            //*************************************************
            //Initialization
            //*************************************************
	    // Instantiation
            federate = new AMVS.CNavShipFdApp(); //Initialize the application-specific federate
	    
	    //local data
            NavigationShip = new BindingList<CNavShipHlaObject>();
            Miningship = new BindingList<CMiningShipHlaObject>();
            Asteroids = new BindingList<CAsteroidHlaObject>();

            //UI Initialization
            PrintVersion();

            // Racon Initialization
            // Getting the information/debugging messages from RACoN
	    Console.WriteLine("-------------");
            manager.federate.StatusMessageChanged += Federate_StatusMessageChanged;
            manager.federate.LogLevel = LogLevel.ALL;
	    Console.WriteLine("-------------");

	    //initialize Navship Properties
	    Console.ForegroundColor = ConsoleColor.Yellow;
            Thread ConsoleKeyListener = new Thread(new ThreadStart(ProcessKeyboard));
            ConsoleKeyListener.Name = "KeyListener";
            ConsoleKeyListener.Start();// start keyboard event listener


           // *************************************************
           // RTI Initialization
           // *************************************************
	   Console.WriteLine("--\nRTI Initialization\n--");
            // Initialize the federation execution in simulation manager
            // Initialize Federation
            bool result = manager.federate.InitializeFederation(manager.federate.FederationExecution);

            /// Connect
            manager.federate.Connect(Racon.CallbackModel.EVOKED, manager.federate.FederationExecution.ConnectionSettings);
            // Create federation execution
            manager.federate.CreateFederationExecution(manager.federate.FederationExecution.Name, manager.federate.FederationExecution.FomModules);
            // Join federation execution
            manager.federate.JoinFederationExecution(manager.federate.FederationExecution.FederateName, manager.federate.FederationExecution.FederateType, manager.federate.FederationExecution.Name, manager.federate.FederationExecution.FomModules);

            // Declare Capability
            manager.federate.DeclareCapability();
   
           // *************************************************
      	   // Main Simulation Loop - loops until ESC is pressed
      	   // *************************************************
           
	   Program.setNavigationShipConfiguration();
           Console.WriteLine("--> Navship federate is running.. \n--");
	   do
      	   {
                // process rti events (callbacks) and tick
        	if (manager.federate.FederateState.HasFlag(FederateStates.JOINED))
          		manager.federate.Run();

      	   } while (!Terminate);
	
	  // *************************************************
      	  // Shutdown
      	  // *************************************************
          // Finalize user interface
      	  ConsoleKeyListener.Abort();
      	  // Finalize Federation Execution
      	  // Remove objects
      	 // federate.DeleteObjectInstance(NavigationShip);
      
      	  // Leave and destroy federation execution
	  Console.WriteLine(">>> Federation is shutting down!..");
      	  bool result2 = federate.FinalizeFederation(federate.FederationExecution, ResignAction.NO_ACTION);
	  
	  // Dumb trace log
            System.IO.StreamWriter file = new System.IO.StreamWriter(@".\TraceLog.txt");
            file.WriteLine(manager.federate.TraceLog);
            file.Close();
	  // Keep the console window open in debug mode.
      	  Console.WriteLine("Press any key to exit.");
      	  Console.ReadKey();
        }//end main

	private static void ProcessKeyboard()
	{
		do
		{
		  //processing input
		  switch(Console.ReadKey(true).Key)
		  {
			case ConsoleKey.Escape:
				Terminate = true;
				break;
			case ConsoleKey.P:
				Console.ForegroundColor = ConsoleColor.Blue;
				printStatus();
				break;
		case ConsoleKey.M:
                        Console.ForegroundColor = ConsoleColor.Blue;
			bool res = manager.federate.SendMessage("mine asteroid");
                        Console.WriteLine($" --> begin mining \n---");
                        break;

                   case ConsoleKey.F:
                        Console.ForegroundColor = ConsoleColor.Blue;
			bool res1 = manager.federate.SendMessage("change direction");
                        Console.WriteLine($" --> ChangingDirection \n---");
                        break;

		  }
		}while(true);
	}

	private static void setNavigationShipConfiguration()
	{
		//create Navship
		CNavShipHlaObject newNavShip = new CNavShipHlaObject(manager.federate.Som.NavShipOC);

            //initialize NavShip
            newNavShip.status = "Stationary, waiting to link with Mining ship...";
            newNavShip.heading = "East";
		newNavShip.position = "(0,0)";
		
		//Encapsulate
		NavigationShip.Add(newNavShip);
		Console.WriteLine($"--------\n The Navigation Ship is online and functional");
	}

        // Racon Information received
        private static void Federate_StatusMessageChanged(object sender, EventArgs e)
        {
            Console.ResetColor();
            Console.WriteLine((sender as CNavShipFdApp).StatusMessage);
        }

	private static void printStatus()
	{
	    // Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("------------------ Navigation Ship Status ----------------");
	    Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine($"---\n NavShip Heading : {NavigationShip[0].heading}");
	    Console.WriteLine($"---\n NavShip Position : {NavigationShip[0].position}");
	    Console.WriteLine($"---\n NavShip Status : {NavigationShip[0].status}");
	    if(Miningship.Count == 0)
	    {
	    	Console.WriteLine("Mining Ship Linked up yet...");
	    }
	    Console.WriteLine("NavShip :");
            
            Console.WriteLine("--------------------------------------------------");
	}

        private static void PrintVersion()
        {
            Console.WriteLine(
              "***********************************************************************************\n"
              + "                        " + " NavShipFdApp v1.0.0 " + "\n"
              + "***********************************************************************************");
        }
    }
}
