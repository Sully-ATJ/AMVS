// **************************************************************************************************
//		CMiningShipFdApp
//
//		generated
//			by		: 	Simulation Generator (SimGe) v.0.3.3
//			at		: 	Wednesday, January 26, 2022 12:35:07 AM
//		compatible with		: 	RACoN v.0.0.2.5
//
//		copyright		: 	(C) 
//		email			: 	
// **************************************************************************************************
/// <summary>
/// The application specific federate that is extended from the Generic Federate Class of RACoN API. This file is intended for manual code operations.
/// </summary>

// System
using System;
using System.Collections.Generic; // for List
// Racon
using Racon;
using Racon.RtiLayer;
// Application
using AMVS.Som;

namespace AMVS
{
  //CMiningShipFdApp extends and specializes the generic federate
  public partial class CMiningShipFdApp : Racon.CGenericFederate
  {
    #region Manually Added Code
    
    // Local Data
    private CSimulationManager manager;
    
    #region Constructor
    public CMiningShipFdApp(CSimulationManager parent) : this()
    {
      manager = parent; // Set simulation manager
      // Create regions manually
    }
    #endregion //Constructor

    #region Federation Management Callbacks
     // FdAmb_OnSynchronizationPointRegistrationConfirmedHandler
    public override void FdAmb_OnSynchronizationPointRegistrationConfirmedHandler(object sender, HlaFederationManagementEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_OnSynchronizationPointRegistrationConfirmedHandler(sender, data);
      
      #region User Code
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine($" >>>>> ({data.Label}) is registered. -------\n" + Environment.NewLine);
           // Console.WriteLine($"Registered Syncronized Data: {manager.SynchronData}");
      #endregion //User Code
    }
    // FdAmb_OnSynchronizationPointRegistrationFailedHandler
    public override void FdAmb_OnSynchronizationPointRegistrationFailedHandler(object sender, HlaFederationManagementEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_OnSynchronizationPointRegistrationFailedHandler(sender, data);
      
      #region User Code
      throw new NotImplementedException("FdAmb_OnSynchronizationPointRegistrationFailedHandler");
      #endregion //User Code
    }
    // FdAmb_SynchronizationPointAnnounced
    public override void FdAmb_SynchronizationPointAnnounced(object sender, HlaFederationManagementEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_SynchronizationPointAnnounced(sender, data);
      
      #region User Code
      throw new NotImplementedException("FdAmb_SynchronizationPointAnnounced");
      #endregion //User Code
    }
    // FdAmb_FederationSynchronized
    public override void FdAmb_FederationSynchronized(object sender, HlaFederationManagementEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_FederationSynchronized(sender, data);
      
      #region User Code
       Console.Write($">>>>simulation pacing ({data.Label}) is completed." + Environment.NewLine);
      #endregion //User Code
    }
    #endregion //Federation Management Callbacks
    #region Declaration Management Callbacks

    // FdAmb_TurnInteractionsOffAdvisedHandler
    public override void FdAmb_TurnInteractionsOffAdvisedHandler(object sender, HlaDeclarationManagementEventArgs data)
    {
      // Call the base class handler
  
      base.FdAmb_TurnInteractionsOffAdvisedHandler(sender, data);
      
      #region User Code
      throw new NotImplementedException("FdAmb_TurnInteractionsOffAdvisedHandler");
      #endregion //User Code
    }
    // FdAmb_TurnInteractionsOnAdvisedHandler
    public override void FdAmb_TurnInteractionsOnAdvisedHandler(object sender, HlaDeclarationManagementEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_TurnInteractionsOnAdvisedHandler(sender, data);
      
      #region User Code
      Console.WriteLine(">>>>>Ready to receive interactions.");
      
      #endregion //User Code
    }

   // FdAmb_InteractionReceivedHandler
    public override void FdAmb_InteractionReceivedHandler(object sender, HlaInteractionEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_InteractionReceivedHandler(sender, data);

            #region User Code
            //check interaction type
            if (data.Interaction.ClassHandle == Som.NavShipMessageIC.Handle)
            {
                string direction = "";
                string capacitystatus = "";
                var ts = new DateTime();


                foreach (var item in data.Interaction.Parameters)
                {
                    if (Som.NavShipMessageIC.NewDirection.Handle == item.Handle) direction = item.GetValue<string>();
                    // else if (Som.MiningShipMessageIC.CapacityStatus.Handle == item.Handle) capacitystatus = item.GetValue<string>();

                }
                if (direction == "mine asteroid") {
                    Console.WriteLine("----\n<<<< Interaction received\n sender: NavShip" + "\n Msg " + "Mine Asteroid\n---");
                }
                else if (direction == "change direction") {
                    Console.WriteLine("----\n<<<< Interaction received\n sender: NavShip" + "\n Msg: " + "Change Direction\n---");
                }
            }
            }


    // FdAmb_StartRegistrationForObjectClassAdvisedHandler
    public override void FdAmb_StartRegistrationForObjectClassAdvisedHandler(object sender, HlaDeclarationManagementEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_StartRegistrationForObjectClassAdvisedHandler(sender, data);
      
      #region User Code
      
      #endregion //User Code
    }
    // FdAmb_StopRegistrationForObjectClassAdvisedHandler
    public override void FdAmb_StopRegistrationForObjectClassAdvisedHandler(object sender, HlaDeclarationManagementEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_StopRegistrationForObjectClassAdvisedHandler(sender, data);
      
      #region User Code
      throw new NotImplementedException("FdAmb_StopRegistrationForObjectClassAdvisedHandler");
      #endregion //User Code
    }
    #endregion //Declaration Management Callbacks

    #region Object Management Callbacks
    public override void FdAmb_ObjectDiscoveredHandler(object sender, HlaObjectEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_ObjectDiscoveredHandler(sender, data);

            #region User Code
            // Check the class type of the discovered object - Navship, MiningShip or Asteroid
            if (data.ClassHandle == Som.NavShipOC.Handle) // Navigation Ship
            {
                // Create and add a new naigation ship to the list
                CNavShipHlaObject newNS = new CNavShipHlaObject(data.ObjectInstance);
                newNS.Type = Som.NavShipOC;
                Program.NavigationShip.Add(newNS);
                Console.WriteLine($"--------New navship discovered!!-------");
		Program.Miningship[0].status = "Linked with Navigation ship, now exploring the asteroid belt!";
                // Request Update Values of Attributes        
                RequestAttributeValueUpdate(newNS, null);
            }
            else if (data.ClassHandle == Som.MiningShipOC.Handle) // A Mining Ship
            {
                // Create and add a new mining ship to the list
                CMiningShipHlaObject newMS = new CMiningShipHlaObject(data.ObjectInstance);
                newMS.Type = Som.MiningShipOC;
                Program.Miningship.Add(newMS);
                Console.WriteLine($"--------New MiningShip discovered!!-------");

                // Request Update Values of Attributes        
                // (1) Request update values of all attributes for a specific object instance
                RequestAttributeValueUpdate(newMS, null);
            }
            else if (data.ClassHandle == Som.AsteroidOC.Handle) // An Asteroid
            {
                // Create and add a new asteroid to the list
                CAsteroidHlaObject newAsteroid = new CAsteroidHlaObject(data.ObjectInstance);
                newAsteroid.Type = Som.AsteroidOC;
                Program.Asteroids.Add(newAsteroid);
                Console.WriteLine($"--------New Asteriod discovered!!-------");

                // Request Update Values of Attributes        
                // (1) Request update values of all attributes for a specific object instance
                RequestAttributeValueUpdate(newAsteroid, null);
            }
      #endregion //User Code
    }
    // FdAmb_ObjectRemovedHandler
    public override void FdAmb_ObjectRemovedHandler(object sender, HlaObjectEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_ObjectRemovedHandler(sender, data);
      
      #region User Code
      Console.WriteLine("in object removed handler.");
      #endregion //User Code
    }
    // FdAmb_AttributeValueUpdateRequestedHandler
    public override void FdAmb_AttributeValueUpdateRequestedHandler(object sender, HlaObjectEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_AttributeValueUpdateRequestedHandler(sender, data);
      
      #region User Code
      throw new NotImplementedException("FdAmb_AttributeValueUpdateRequestedHandler");
      #endregion //User Code
    }
    // FdAmb_ObjectAttributesReflectedHandler
    public override void FdAmb_ObjectAttributesReflectedHandler(object sender, HlaObjectEventArgs data)
    {
      // Call the base class handler
      base.FdAmb_ObjectAttributesReflectedHandler(sender, data);
      
      #region User Code
      throw new NotImplementedException("FdAmb_ObjectAttributesReflectedHandler");
      #endregion //User Code
    }
    

        #endregion //Object Management Callbacks
        #region Ownership Management Callbacks
        #endregion

	public bool SendMessage(bool status)
	{
		
		HlaInteraction interaction = new Racon.RtiLayer.HlaInteraction(Som.MiningShipMessageIC, "MiningShipMessage");
		interaction.AddParameterValue(Som.MiningShipMessageIC.MiningStatus, status); // bool
		

		try
      		{
        	SendInteraction(interaction);
        	//MessageRetraction handle = SendInteraction(interaction);
        	//Retract(handle);
       		return true;
      		}
      		catch (Exception)
      		{
        		return false;
      		}
            #endregion
        }
        #endregion //Manually Added Code
    }
}
