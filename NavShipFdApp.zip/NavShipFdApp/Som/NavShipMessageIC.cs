// **************************************************************************************************
//		CNavShipMessageIC
//
//		generated
//			by		: 	Simulation Generator (SimGe) v.0.3.3
//			at		: 	Wednesday, January 26, 2022 12:35:06 AM
//		compatible with		: 	RACoN v.0.0.2.5
//
//		copyright		: 	(C) 
//		email			: 	
// **************************************************************************************************
/// <summary>
/// This class is extended from the object model of RACoN API
/// </summary>

// System
using System;
using System.Collections.Generic; // for List
// Racon
using Racon;
using Racon.RtiLayer;
// Application
using AMVS.Som;


namespace AMVS.Som
{
  public class CNavShipMessageIC : HlaInteractionClass
  {
    #region Declarations
    public HlaParameter NewDirection;
    #endregion //Declarations
    
    #region Constructor
    public CNavShipMessageIC() : base()
    {
      // Initialize Class Properties
      Name = "HLAinteractionRoot.NavShipMessage";
      ClassPS = PSKind.PublishSubscribe;
      
      // Create Parameters
      // NewDirection
      NewDirection = new HlaParameter("NewDirection");
      Parameters.Add(NewDirection);
    }
    #endregion //Constructor
  }
}
