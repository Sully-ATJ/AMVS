// **************************************************************************************************
//		CMiningShipOC
//
//		generated
//			by		: 	Simulation Generator (SimGe) v.0.3.3
//			at		: 	Wednesday, January 26, 2022 12:35:06 AM
//		compatible with		: 	RACoN v.0.0.2.5
//
//		copyright		: 	(C) 
//		email			: 	
// **************************************************************************************************
/// <summary>
/// This class is extended from the object model of RACoN API
/// </summary>

// System
using System;
using System.Collections.Generic; // for List
// Racon
using Racon;
using Racon.RtiLayer;
// Application
using AMVS.Som;


namespace AMVS.Som
{
  public class CMiningShipOC : HlaObjectClass
  {
    #region Declarations
    public HlaAttribute MCapacity;
    public HlaAttribute MStatus;
    public HlaAttribute MPosition;
    public HlaAttribute MHeading;
    #endregion //Declarations
    
    #region Constructor
    public CMiningShipOC() : base()
    {
      // Initialize Class Properties
      Name = "HLAobjectRoot.MiningShip";
      ClassPS = PSKind.Subscribe;
      
      // Create Attributes
      // MCapacity
      MCapacity = new HlaAttribute("MCapacity", PSKind.PublishSubscribe);
      Attributes.Add(MCapacity);
      // MStatus
      MStatus = new HlaAttribute("MStatus", PSKind.PublishSubscribe);
      Attributes.Add(MStatus);
      // MPosition
      MPosition = new HlaAttribute("MPosition", PSKind.PublishSubscribe);
      Attributes.Add(MPosition);
      // MHeading
      MHeading = new HlaAttribute("MHeading", PSKind.PublishSubscribe);
      Attributes.Add(MHeading);
    }
    #endregion //Constructor
  }
}
