// **************************************************************************************************
//		CAsteroidOC
//
//		generated
//			by		: 	Simulation Generator (SimGe) v.0.3.3
//			at		: 	Wednesday, January 26, 2022 12:35:06 AM
//		compatible with		: 	RACoN v.0.0.2.5
//
//		copyright		: 	(C) 
//		email			: 	
// **************************************************************************************************
/// <summary>
/// This class is extended from the object model of RACoN API
/// </summary>

// System
using System;
using System.Collections.Generic; // for List
// Racon
using Racon;
using Racon.RtiLayer;
// Application
using AMVS.Som;


namespace AMVS.Som
{
  public class CAsteroidOC : HlaObjectClass
  {
    #region Declarations
    public HlaAttribute AsteroidType;
    public HlaAttribute AHeading;
    public HlaAttribute APosition;
    #endregion //Declarations
    
    #region Constructor
    public CAsteroidOC() : base()
    {
      // Initialize Class Properties
      Name = "HLAobjectRoot.Asteroid";
      ClassPS = PSKind.Subscribe;
      
      // Create Attributes
      // AsteroidType
      AsteroidType = new HlaAttribute("AsteroidType", PSKind.PublishSubscribe);
      Attributes.Add(AsteroidType);
      // AHeading
      AHeading = new HlaAttribute("AHeading", PSKind.PublishSubscribe);
      Attributes.Add(AHeading);
      // APosition
      APosition = new HlaAttribute("APosition", PSKind.PublishSubscribe);
      Attributes.Add(APosition);
    }
    #endregion //Constructor
  }
}
